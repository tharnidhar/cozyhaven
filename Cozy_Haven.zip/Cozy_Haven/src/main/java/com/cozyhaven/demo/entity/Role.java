package com.cozyhaven.demo.entity;


public enum Role {
    GUEST,
    OWNER,
    ADMIN
}
