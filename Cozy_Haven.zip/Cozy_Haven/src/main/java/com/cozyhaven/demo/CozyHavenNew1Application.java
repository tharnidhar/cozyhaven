package com.cozyhaven.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CozyHavenNew1Application {

	public static void main(String[] args) {
		SpringApplication.run(CozyHavenNew1Application.class, args);
		System.out.println("App started");
	}

}
