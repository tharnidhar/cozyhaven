package com.cozyhaven.demo.service;


import com.cozyhaven.demo.entity.Hotel;

import java.util.List;

public interface HotelService {
    Hotel addHotel(Hotel hotel);
    Hotel getHotelById(Long id);
    List<Hotel> getAllHotels();
    List<Hotel> searchHotelsByLocation(String location);
    void deleteHotel(Long id);
}
