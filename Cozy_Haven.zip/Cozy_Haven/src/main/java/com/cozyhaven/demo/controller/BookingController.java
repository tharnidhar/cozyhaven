package com.cozyhaven.demo.controller;


import com.cozyhaven.demo.dto.BookingDTO;
import com.cozyhaven.demo.entity.Booking;
import com.cozyhaven.demo.entity.Room;
import com.cozyhaven.demo.entity.User;
import com.cozyhaven.demo.service.BookingService;
import com.cozyhaven.demo.service.RoomService;
import com.cozyhaven.demo.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;
    private final UserService userService;
    private final RoomService roomService;

    @PostMapping
    public BookingDTO createBooking(@RequestBody BookingDTO dto) {
        User user = userService.getUserById(dto.getUserId()).orElse(null);
        Room room = roomService.getRoomById(dto.getRoomId());

        Booking booking = Booking.builder()
                .user(user)
                .room(room)
                .checkInDate(dto.getCheckInDate())
                .checkOutDate(dto.getCheckOutDate())
                .numberOfAdults(dto.getNumberOfAdults())
                .numberOfChildren(dto.getNumberOfChildren())
                .numberOfRooms(dto.getNumberOfRooms())
                .totalFare(dto.getTotalFare())
                .status("BOOKED")
                .build();

        return toDTO(bookingService.createBooking(booking));
    }

    @GetMapping("/user/{userId}")
    public List<BookingDTO> getUserBookings(@PathVariable Long userId) {
        User user = userService.getUserById(userId).orElse(null);
        return bookingService.getBookingsByUser(user)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    @DeleteMapping("/{id}")
    public void cancelBooking(@PathVariable Long id) {
        bookingService.cancelBooking(id);
    }

    private BookingDTO toDTO(Booking b) {
        BookingDTO dto = new BookingDTO();
        dto.setId(b.getId());
        dto.setUserId(b.getUser().getId());
        dto.setRoomId(b.getRoom().getId());
        dto.setCheckInDate(b.getCheckInDate());
        dto.setCheckOutDate(b.getCheckOutDate());
        dto.setNumberOfAdults(b.getNumberOfAdults());
        dto.setNumberOfChildren(b.getNumberOfChildren());
        dto.setNumberOfRooms(b.getNumberOfRooms());
        dto.setTotalFare(b.getTotalFare());
        dto.setStatus(b.getStatus());
        return dto;
    }
}
