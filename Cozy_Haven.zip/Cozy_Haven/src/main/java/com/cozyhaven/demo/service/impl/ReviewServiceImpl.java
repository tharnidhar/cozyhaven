package com.cozyhaven.demo.service.impl;

import com.cozyhaven.demo.entity.Hotel;
import com.cozyhaven.demo.entity.Review;
import com.cozyhaven.demo.repository.ReviewRepository;
import com.cozyhaven.demo.service.ReviewService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ReviewServiceImpl implements ReviewService {

    private final ReviewRepository reviewRepository;

    @Override
    public Review addReview(Review review) {
        return reviewRepository.save(review);
    }

    @Override
    public List<Review> getReviewsByHotel(Hotel hotel) {
        return reviewRepository.findByHotel(hotel);
    }
}
