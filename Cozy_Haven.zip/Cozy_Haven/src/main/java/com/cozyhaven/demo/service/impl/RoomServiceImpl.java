package com.cozyhaven.demo.service.impl;


import com.cozyhaven.demo.entity.Hotel;
import com.cozyhaven.demo.entity.Room;
import com.cozyhaven.demo.repository.RoomRepository;
import com.cozyhaven.demo.service.RoomService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RoomServiceImpl implements RoomService {

    private final RoomRepository roomRepository;

    @Override
    public Room addRoom(Room room) {
        return roomRepository.save(room);
    }

    @Override
    public Room getRoomById(Long id) {
        return roomRepository.findById(id).orElse(null);
    }

    @Override
    public List<Room> getRoomsByHotel(Hotel hotel) {
        return roomRepository.findByHotel(hotel);
    }

    @Override
    public void deleteRoom(Long id) {
        roomRepository.deleteById(id);
    }
}
