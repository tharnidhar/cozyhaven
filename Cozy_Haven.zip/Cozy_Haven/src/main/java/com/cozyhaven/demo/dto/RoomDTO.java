package com.cozyhaven.demo.dto;


import lombok.Data;

@Data
public class RoomDTO {
    private Long id;
    private String roomSize;
    private String bedType;
    private Integer maxOccupancy;
    private Double baseFare;
    private Boolean ac;
    private Long hotelId;
}
