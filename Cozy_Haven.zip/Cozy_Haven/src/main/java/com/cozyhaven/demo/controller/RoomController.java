package com.cozyhaven.demo.controller;


import com.cozyhaven.demo.dto.RoomDTO;
import com.cozyhaven.demo.entity.Hotel;
import com.cozyhaven.demo.entity.Room;
import com.cozyhaven.demo.service.HotelService;
import com.cozyhaven.demo.service.RoomService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/rooms")
@RequiredArgsConstructor
public class RoomController {

    private final RoomService roomService;
    private final HotelService hotelService;

    @PostMapping
    public RoomDTO addRoom(@RequestBody RoomDTO dto) {
        Hotel hotel = hotelService.getHotelById(dto.getHotelId());
        Room room = Room.builder()
                .roomSize(dto.getRoomSize())
                .bedType(dto.getBedType())
                .maxOccupancy(dto.getMaxOccupancy())
                .baseFare(dto.getBaseFare())
                .ac(dto.getAc())
                .hotel(hotel)
                .build();
        return toDTO(roomService.addRoom(room));
    }

    @GetMapping("/hotel/{hotelId}")
    public List<RoomDTO> getRoomsByHotel(@PathVariable Long hotelId) {
        Hotel hotel = hotelService.getHotelById(hotelId);
        return roomService.getRoomsByHotel(hotel)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    @DeleteMapping("/{id}")
    public void deleteRoom(@PathVariable Long id) {
        roomService.deleteRoom(id);
    }

    private RoomDTO toDTO(Room room) {
        RoomDTO dto = new RoomDTO();
        dto.setId(room.getId());
        dto.setRoomSize(room.getRoomSize());
        dto.setBedType(room.getBedType());
        dto.setMaxOccupancy(room.getMaxOccupancy());
        dto.setBaseFare(room.getBaseFare());
        dto.setAc(room.getAc());
        dto.setHotelId(room.getHotel().getId());
        return dto;
    }
}

