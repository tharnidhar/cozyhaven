package com.cozyhaven.demo.repository;


import com.cozyhaven.demo.entity.Hotel;
import com.cozyhaven.demo.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReviewRepository extends JpaRepository<Review, Long> {
    List<Review> findByHotel(Hotel hotel);
}
