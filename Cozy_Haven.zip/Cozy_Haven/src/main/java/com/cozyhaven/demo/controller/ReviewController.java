package com.cozyhaven.demo.controller;


import com.cozyhaven.demo.dto.ReviewDTO;
import com.cozyhaven.demo.entity.Hotel;
import com.cozyhaven.demo.entity.Review;
import com.cozyhaven.demo.entity.User;
import com.cozyhaven.demo.service.HotelService;
import com.cozyhaven.demo.service.ReviewService;
import com.cozyhaven.demo.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/reviews")
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;
    private final UserService userService;
    private final HotelService hotelService;

    @PostMapping
    public ReviewDTO addReview(@RequestBody ReviewDTO dto) {
        User user = userService.getUserById(dto.getUserId()).orElse(null);
        Hotel hotel = hotelService.getHotelById(dto.getHotelId());

        Review review = Review.builder()
                .user(user)
                .hotel(hotel)
                .rating(dto.getRating())
                .comment(dto.getComment())
                .build();

        return toDTO(reviewService.addReview(review));
    }

    @GetMapping("/hotel/{hotelId}")
    public List<ReviewDTO> getHotelReviews(@PathVariable Long hotelId) {
        Hotel hotel = hotelService.getHotelById(hotelId);
        return reviewService.getReviewsByHotel(hotel)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    private ReviewDTO toDTO(Review r) {
        ReviewDTO dto = new ReviewDTO();
        dto.setId(r.getId());
        dto.setUserId(r.getUser().getId());
        dto.setHotelId(r.getHotel().getId());
        dto.setRating(r.getRating());
        dto.setComment(r.getComment());
        return dto;
    }
}
