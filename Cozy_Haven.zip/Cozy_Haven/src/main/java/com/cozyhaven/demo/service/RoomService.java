package com.cozyhaven.demo.service;


import com.cozyhaven.demo.entity.Hotel;
import com.cozyhaven.demo.entity.Room;

import java.util.List;

public interface RoomService {
    Room addRoom(Room room);
    Room getRoomById(Long id);
    List<Room> getRoomsByHotel(Hotel hotel);
    void deleteRoom(Long id);
}

