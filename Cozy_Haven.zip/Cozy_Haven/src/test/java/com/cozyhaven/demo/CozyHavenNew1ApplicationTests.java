package com.cozyhaven.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CozyHavenNew1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
